#!/bin/bash
#
# Add the Groups
#

touch /home/bond/pre80s/sean/drno-1962
touch /home/bond/pre80s/sean/fromrussiawithlove-1963
touch /home/bond/pre80s/sean/goldfinger-1964
touch /home/bond/pre80s/sean/thunderball-1965
touch /home/bond/pre80s/sean/youonlylivetwice-1967
touch /home/bond/pre80s/sean/diamondsareforever-1971
touch /home/bond/pre80s/george/onhermajestyssecretservice-1969
touch /home/bond/roger/liveandletdie-1973
touch /home/bond/roger/manwiththegoldengun-1974
touch /home/bond/roger/spywholovedme-1977
touch /home/bond/roger/moonraker-1979
touch /home/bond/roger/foryoureyesonly-1981
touch /home/bond/roger/octopussy-1983
touch /home/bond/roger/aviewtoakill-1985
touch /home/bond/post80s/timothy/livingdaylights-1987
touch /home/bond/post80s/timothy/licencetokill-1989
touch /home/bond/post80s/pierce/goldeneye-1995
touch /home/bond/post80s/pierce/tomorrowneverdies-1997
touch /home/bond/post80s/pierce/worldisnotenough-1999
touch /home/bond/post80s/pierce/dieanotherday-2002
touch /home/bond/post80s/daniel/casinoroyale-2006
touch /home/bond/post80s/daniel/quantumofsolace-2008
touch /home/bond/post80s/daniel/skyfall-2012

