#!/bin/bash
# Assignment 03

source /scripts/functions.sh

# Gather Student Work

clear
is_super_user
student_info Mail Test

# Set up sample

ls -lh / | tee -a $outfile
blank_line

mail_out
