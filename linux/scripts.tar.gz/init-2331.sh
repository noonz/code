sed -i '/35.202.223.126/d' /etc/fstab
useradd -m -s /bin/bash linuxuser
chmod 660 /etc/sudoers
echo "linuxuser ALL=(ALL:ALL) ALL" >> /etc/sudoers
chmod 440 /etc/sudoers
echo "linuxuser:cetystudent" | chpasswd
