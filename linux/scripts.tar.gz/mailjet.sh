#!/bin/bash

#outfile=/tmp/a3929-lab3_D_Cushing.txt
#fname=Dave
#lname=Cushing
#a1=Lab
#a2=03
#content=`base64 -w0 $outfile`

curl -s \
     -X POST \
     --user "0e05bb443d2de5778386c9c8424b3a4a:f7015386c733813f5235787dec722700" \
     https://api.mailjet.com/v3/REST/sender \
     -H 'Content-Type: application/json' \
     -d '{
				"EmailType": "bulk",
				"IsDefaultSender": false,
				"Name": "GCP Home",
				"Email": "dmc1208_gmail_com@dave.c.home-cushing.internal"
			}'


#curl -s \
#  -X POST \
#  --user "0e05bb443d2de5778386c9c8424b3a4a:f7015386c733813f5235787dec722700" \
#  https://api.mailjet.com/v3/send \
#  -H 'Content-Type: application/json' \
#  -d '{
#    "FromEmail":"dave.cushing@cambriancollege.ca",
#    "FromName":"Dave Cushing",
#    "Subject":"'"$fname $lname: $a1 $a2"'",
#    "Text-part":"'"Lab Submission: "'",
#    "Inline_attachments":[
#	{
#	    "Content-type":"text/plain",
#	    "Filename":"test.txt",
#	    "content":"'"$content "'"}],
#   "Recipients":[
#        {
#            "Email": "dmc1208@gmail.com"
#        }
#    ]
#  }'
